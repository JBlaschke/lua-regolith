require("lazymodule.1")
