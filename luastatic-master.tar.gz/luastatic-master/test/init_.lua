require("foo")
